/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

"use strict";

const TMSC = require("./lib/tmsc");

module.exports.TMSC = TMSC;
module.exports.contracts = [TMSC];
