import api from "./api";

export function getClientExecutable(payload, percentageCallback) {
  api.getClientExecutable(payload, percentageCallback);
}
