module.exports = [
  "attikon-hospital",
  "general-hospital-of-athens",
  "medutils",
  "healthprods",
];
