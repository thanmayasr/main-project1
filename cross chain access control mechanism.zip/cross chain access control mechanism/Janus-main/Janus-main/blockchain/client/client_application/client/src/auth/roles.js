const authRoles = {
    client: ["client"],
    admin: ["admin"],
    caAdmin: ["caAdmin"],
    auditor: ["auditor"],
    guest: [],
};

export default authRoles;
