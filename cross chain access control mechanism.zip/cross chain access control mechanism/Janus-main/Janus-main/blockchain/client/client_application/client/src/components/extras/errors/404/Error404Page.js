import React from "react";

const Error404Page = () => (
    <div>
        <h1>You've reached the Void</h1>
    </div>
);

export default Error404Page;
