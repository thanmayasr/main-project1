module.exports = Object.freeze({
    baseUrl: "",
});
